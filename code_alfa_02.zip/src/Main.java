

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import res.ControleC1;

/**
 *
 * @author nataniel
 */
public class Main extends Application {

    @Override
    public void start(Stage ps) {
        File f = null;
        
        try {
            f=new File(System.getProperty("user.dir").concat("/renomear_nataniel_01.temp"));
            if (!f.exists()) {
                f.createNewFile();
                Alert ale=new Alert(Alert.AlertType.INFORMATION);
                ale.setTitle("Criador");
                ale.setHeaderText("Criado por Nataniel");
                ale.setContentText("Para contado:\nTelegram: @Neoold\nEmail:natanieljava@gmail.com");
                ale.showAndWait();
                ale.setTitle("Versão ALFA 2");
                ale.setHeaderText("Log");
                ale.setContentText("Versão ALFA_2:"
                        + "\n-Corrigido bugs com o linux (acesso a pasta\n"
                        + "temp sem su)"
                        + "\n-Corrigido bugs com relação aos bugs com num-\n"
                        + "com o zero no inicio"
                        + "\nVersão ALFA_1"
                        + "\n-Adicionado recurso para renomeação basica.");
                ale.showAndWait();
            }
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        Parent par = null;
        FXMLLoader lod = new FXMLLoader(getClass().getResource("/res/cena1.fxml"));
        try {
            par = lod.load();
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        ControleC1 contro = (ControleC1) lod.getController();
        Scene sc = new Scene(par);
        ps.setScene(sc);
        ps.setResizable(false);
        ps.setTitle("Renomear - ALFA_02");
        ps.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
